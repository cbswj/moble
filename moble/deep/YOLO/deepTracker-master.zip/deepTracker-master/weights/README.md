
## Directory to store yolo weights files

To download pretrained YOLO weights use in Keras format:
wget http://www.maths.gla.ac.uk/~ctorney/weights/yolo-v3-coco.h5
