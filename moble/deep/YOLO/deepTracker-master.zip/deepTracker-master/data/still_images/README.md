
## Directory still images from videos for training. 
Around 500 images from all different videos should be enough
