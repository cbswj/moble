# MY_YOLO
yolo algorithm to detect animals
![Kangaroo detection using YOLO](kangaroo3.jpg)
