#pragma once
#include "student.h"

void studentInfo(Student* st);

void korSave(Student* st);

void engSave(Student* st);

void mathSave(Student* st);

void scoreAvg(Student* st);

void totalAvg(Student* st);

void rankprint(Student* st);

void row_delete(Student* st);

void id_print(Student* st);

void total_print(Student* st);

Student* swap(Student* swap1, Student* swap2);

