#include <iostream>
#include "student.h"

using namespace std;



void Student::setIdName(int id, const char name[]) {
	this->id = id;
	strcpy(this->name, name);
}

void Student::setStudent(int id, const char name[], int kor, int eng, int math) {
	this->id = id;
	strcpy(this->name, name);
	this->kor = kor;
	this->eng = eng;
	this->math = math;
}

void Student::getStudent() {
	cout << "���̵� : " << id << ",  �̸� : " << name << ", ";
	cout << "���� ���� : " << kor << ", ";
	cout << "���� ���� : " << eng << ", ";
	cout << "���� ���� : " << math << ", ";
	cout << "��� ���� : " << avg << "\n";
}

void Student::showInfo() {
	this->avg = (kor + eng + math) / 3.0;
	cout << "��� : " << avg << "\n";
}

void Student::setEng(int eng) {
	this->eng = eng;

}
void Student::setKor(int kor) {
	this->kor = kor;
}

void Student::setMath(int math) {
	this->math = math;
}

int Student::getEng() {
	return eng;
}

int Student::getKor() {
	return kor;
}

int Student::getMath() {
	return math;
}

char* Student::getName() {
	return name;
}