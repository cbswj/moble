#pragma once


class Student {
public:
	int id;
	char name[50];
	int kor;
	int eng;
	int math;
	double avg;
	Student* next;
	Student* before;


	void showInfo();

	void setIdName(int id, const char name[]);
	void setStudent(int id, const char name[], int kor = -1, int eng = -1, int math = -1);
	char* getName();
	void getStudent();
	void setKor(int kor);
	int getKor();
	void setEng(int eng);
	int getEng();
	void setMath(int math);
	int getMath();
};