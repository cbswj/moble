package manager;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

public class Manager_scholar extends JFrame{
   Choice  Professor;
  
   JButton Btn_consulting;
   JTextArea Jta_consulting;
   JPanel gradePanel,gradePanel2,gradePanel3,scholarship,scholarship2,nullpanel,nullpanel2,nullpanel3,consultPanel,consultPanel2;
   JLabel lbl1,lbl2,lbl3;
   JTable Grade_tb;
   JList scholarship_lst;
   String id,name, c, java,python;
   List<String[]> elements;
   String[] arr_grade = new String[100];
   String splitted[],splitted2[];
   String[][] scholar_arr = new String[100][5];
   String[][] scholar_arr2 = new String[100][4];
   String[] check = new String[100];
   
   String tb_click;
   String tb_click_scholar;
   String tb_click_num;
   int check_check = 0;
   int scholar_count = 0;
   int data_count = 0;
   
   
   
   
   String subject[] = {"�й�","�̸�","C���","Python","Java","���б�"};
   String data[][] = new String[100][6];
   
   
   String list1[];
   String list2[];
   
   int a = 0;
   int rows[] = new int[3];
   int LIST_INDEX = 0; // ���б� �� ����Ʈ
   public Manager_scholar(){

      super("���� ���б�");
      
      setLayout(new FlowLayout());
      EtchedBorder eborder =  new EtchedBorder();
      
      lbl1 = new JLabel("���� ���б�");
      
      add(lbl1);
      
     
      //Grade_tb = new JTable(data, subject);
    //  JScrollPane sp = new JScrollPane(Grade_tb);
      
     
      //table
      try {

          BufferedReader br = new BufferedReader(new FileReader(new File("Grade.csv")));
          String line = null;
          //���پ� �޾ƿ��� �ݺ���!!
          int i = 0;
          while ((line = br.readLine()) != null) {
             //������ ,�� ������ �迭�� ������ִ¹�
             splitted = line.split(",");
           int q = 0;
         scholar_arr[i] = splitted;
         i++;
   
         scholar_count++;
          }
        
          
          br.close();
 
       } catch (Exception ex) {
          ex.printStackTrace();
       }
      try {

          BufferedReader br2 = new BufferedReader(new FileReader(new File("scholarship.csv")));
          String line2 = null;
          //���پ� �޾ƿ��� �ݺ���!!
          int i = 0;
        
          while ((line2 = br2.readLine()) != null) {
             //������ ,�� ������ �迭�� ������ִ¹�
             splitted2 = line2.split(",");
           int q = 0;
         scholar_arr2[i] = splitted2;
         i++;
          }
          br2.close();
       } catch (Exception ex) {
          ex.printStackTrace();
       }
      
      for(int i =0;i<scholar_arr.length; i++) {
         data_count++;
         for(int j =0; j<scholar_arr[i].length;j++) {
            data[i][j] = scholar_arr[i][j];
         }
      }
     check_check = 0;
     
     
      for(int i = 0; i<data.length;i++) { // �й��� �������� �л������� ���бݿ��� �� �� Y�� �й� check �迭�� ����
         if(data[i][0] == null) break;
         for(int j = 0; j< scholar_arr2.length;j++) {
           if(scholar_arr2[j][0] == null) break;
           if(data[i][0].equals(scholar_arr2[j][0])) {
              check[check_check] = data[i][0];
              check_check++;
           }
           
           
         }

      }
      
      //�ϴ� N���� �ʱ�ȭ
      for(int i = 0; i <check.length;i++) {
          if(check[i] == null) break;
          for(int j = 0; j<data.length;j++) {
             if(data[j][0] == null) break;
             if(!check[i].equals(data[j][0])) {
                data[j][5] = "N";
             }
            
          }
       }
      
      //���б� ������ Y�� �ʱ�ȭ
      for(int i = 0; i <check.length;i++) {
         if(check[i] == null) break;
         for(int j = 0; j<data.length;j++) {
            if(data[j][0] == null) break;
            if(check[i].equals(data[j][0])) {
               data[j][5] = "Y";
            }
           
         }
      }
      

      for(int i = 0; i<data.length; i++) {
         for(int j = 0; j<check.length;j++) {
           if(data[i][0] == check[j]) {
          //   data[i][5]  ;
           }
         }
      }

        
      System.out.println();
      Grade_tb = new JTable(data, subject);
      JScrollPane sp1 = new JScrollPane(Grade_tb);
      
      Grade_tb.addMouseListener(new MyMouseListener());
      //table
      
      gradePanel = new JPanel();
      gradePanel2 = new JPanel();
      gradePanel3 = new JPanel();
      consultPanel = new JPanel();
      consultPanel2 = new JPanel();
      nullpanel = new JPanel();
      scholarship = new JPanel();
      scholarship2 = new JPanel();
      nullpanel2 = new JPanel();
      nullpanel3 = new JPanel();
      
      
      gradePanel2.setPreferredSize(new Dimension(1000,150));//(1000,66) 66�κ��� �����ε� �����ؾ���
      nullpanel.setPreferredSize(new Dimension(1000,10));
      nullpanel2.setPreferredSize(new Dimension(1000,10));
      nullpanel3.setPreferredSize(new Dimension(1000,10));
    
      lbl2 = new JLabel("���б� ��û");
      Btn_consulting = new JButton("����");
      Jta_consulting = new JTextArea(3,20);
      JScrollPane consulting_text = new JScrollPane(Jta_consulting);
      
      Professor = new Choice();
      Professor.addItem("�������б�");
      Professor.addItem("�ٷ����б�");
      Professor.addItem("�ູ���б�");
      
      lbl3 = new JLabel("���б� ����");
      DefaultListModel<String> m = new DefaultListModel<>();
      m.addElement(tb_click);
      
      list1 = new String[] {"    ","    ","    "};
      list2 = new String[3];
      scholarship_lst = new JList(list1);
      scholarship_lst.setPreferredSize(new Dimension(60,60));
      
      //���� ��ư
      Btn_consulting.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			//���� ����
			excelSave();
			//���б� Y/N ��ȯ
			scholarTrans();
		
		}
	});
      
      
      gradePanel.add(lbl1);
      gradePanel2.add(sp1);
   
      scholarship.add(lbl3);
      //scholarship.add(scholarship_lst);
      consultPanel.add(lbl2);
      consultPanel2.add(Professor);
      consultPanel2.add(scholarship_lst);
      consultPanel2.add(Btn_consulting);
      
      
      
      add(gradePanel);
      add(gradePanel2);
      add(gradePanel3);
      add(nullpanel);
      add(scholarship);
      add(nullpanel2);
      add(consultPanel);
      add(nullpanel3);
      add(consultPanel2);
      setSize(600,600); //ȭ�� ũ��
      setVisible(true); 
   }
   
   // ���б� ���� Y/N ��ȯ
   public void scholarTrans() {
	   int row = Grade_tb.getSelectedRow();
	   //tb_click_scholar = (String) Grade_tb.getValueAt(row, 5);
	   
	   for(int j=0; j<rows.length; j++) {
			   data[rows[j]][5] = "Y";
			   Grade_tb.repaint();
	   }
   }


   //���б� ��û ���� ����
   public void excelSave() {
	   BufferedWriter scholar_csv;
		//���� ��¥ ��������
		Calendar calendar = Calendar.getInstance();
       java.util.Date date = calendar.getTime();
       
       //��¥ ���ڿ� ����
       String today = (new SimpleDateFormat("yyyy-MM-dd").format(date));
       
       //���б� ����Ʈ�� ��µ� �� csv�� ����
       try {
       	for(int i=0; i<3; i++) {
       		scholar_csv = new BufferedWriter(new FileWriter("scholarship.csv", true));
       		scholar_csv.write(list2[i]+","); // �й�.
       		scholar_csv.write(list1[i]+","); // �̸�
       		scholar_csv.write(Professor.getSelectedItem()+","); // ���б� ����
       		scholar_csv.write(today+"\n"); // ��¥
       		scholar_csv.close();
       	}
			
       } catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
       }
   }
   
   
   // ���̺����� Ŭ���� �� ����Ʈ�� ���
   private class MyMouseListener extends MouseAdapter{
	   public void mouseClicked(MouseEvent e) {
		   if(e.getButton() == 1) {
			   System.out.println("dfdsfdsf");
			   int row = Grade_tb.getSelectedRow(); // ���õ� ��
			   
		
			   
			   tb_click = (String) Grade_tb.getValueAt(row, 1); // �̸�
			   tb_click_num = (String) Grade_tb.getValueAt(row, 0); // �й� 
			   
			   if(LIST_INDEX==3) {
				   LIST_INDEX=0;
			   }
			   
			   if(a==3) {
				   a=0;
			   }
			   
			   rows[a] = row;
			   a++;
			   
			   
			   list1[LIST_INDEX] = tb_click; // ���� ��� �̸���
			   list2[LIST_INDEX] = tb_click_num; // ���� ��� �й���
			   LIST_INDEX++;
			   
			   scholarship_lst.repaint();

		   }
	   }
   }
   //
   
   
   
  
}