package manager;

import java.awt.Choice;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class Manager_student extends JFrame {

   JButton Btn_consulting;
   JTextArea Jta_consulting;
   JPanel gradePanel, gradePanel2, gradePanel3, nullpanel, nullpanel2, nullpanel3, consultPanel, consultPanel2;
   JLabel lbl1;
   JTable Grade_tb;
   JScrollPane scroll;
   String id, pwd, major, name;
   ArrayList<String[]> privacy_array = new ArrayList<>();
   String tb_input;
   List<String[]> elements;
   
   
   
   public Manager_student() {

      super("ȸ�� ����");

      setLayout(new FlowLayout());
      EtchedBorder eborder = new EtchedBorder();

      lbl1 = new JLabel("ȸ�� ����");
      String[] student = new String[] { "�й�", "�̸�", "��� ��ȣ", "����" };
      String[][] data = new String[100][4];
      add(lbl1);

      // table
      try {

         BufferedReader br = new BufferedReader(new FileReader(new File("Student.csv")));
         elements = new ArrayList<String[]>();
         String line = null;
         while ((line = br.readLine()) != null) {
            String[] splitted = line.split(";");
            elements.add(splitted);
         } // csv���Ͽ��� �л� ���� ���� �޾� �´�.
         br.close();

         // JTable table = new JTable();

         String[][] content = new String[elements.size()][4];

         for (int i = 0; i < elements.size(); i++) {// �� �л� ������ 1�ٷ� ������ ����
            content[i][0] = elements.get(i)[0]; // content[i][0]�κп� ���پ� ����

         }

         String strLine = "";
         StringTokenizer st = null;
         int lineNumber = 0, tokenNumber = 0;
         int NAME_TOKEN_NUM = 1, MAJOR_TOKEN_NUM = 4;
         int ID_TOKEN_NUM = 2, PWD_TOKEN_NUM = 3;
         int i = 0;
         int j = 0;

         for (i = 0; i < content.length; i++) { // ���ٷ� ���� ������ �̸� �й� ��й�ȣ �������� ������ ���̺��� ����
            strLine = content[i][0];
            lineNumber++;
            st = new StringTokenizer(strLine, ",");

            while (st.hasMoreTokens()) {
               tokenNumber++;
               if (tokenNumber == ID_TOKEN_NUM) {
                  ID_TOKEN_NUM += 8;
                  id = st.nextToken();
                  data[i][j] = id;
                  j++;
               } else if (tokenNumber == PWD_TOKEN_NUM) {

                  PWD_TOKEN_NUM += 8;
                  pwd = st.nextToken();
                  data[i][j] = pwd;
                  j++;
               } else if (tokenNumber == MAJOR_TOKEN_NUM) {

                  MAJOR_TOKEN_NUM += 8;
                  major = st.nextToken();
                  data[i][j] = major;
                  j = 0;
               } else if (tokenNumber == NAME_TOKEN_NUM) {

                  NAME_TOKEN_NUM += 8;
                  name = st.nextToken();
                  data[i][j] = name;
                  j++;
               }

               else {
                  st.nextToken();
               }
            }

         }
      } catch (Exception ex) {
         ex.printStackTrace();
      }
      
      Grade_tb = new JTable(data, student);

      // table end

      JScrollPane sp = new JScrollPane(Grade_tb);

      Grade_tb.addMouseListener(new MyMouseListener());

      gradePanel = new JPanel();
      gradePanel2 = new JPanel();
      gradePanel3 = new JPanel();
      consultPanel = new JPanel();
      consultPanel2 = new JPanel();
      nullpanel = new JPanel();

      nullpanel2 = new JPanel();
      nullpanel3 = new JPanel();

      gradePanel2.setPreferredSize(new Dimension(1000, 450));// (1000,66) 66�κ��� �����ε� �����ؾ���
      nullpanel.setPreferredSize(new Dimension(1000, 10));
      nullpanel2.setPreferredSize(new Dimension(1000, 10));
      nullpanel3.setPreferredSize(new Dimension(1000, 10));

      scroll = new JScrollPane(gradePanel2);
      Btn_consulting = new JButton("ȸ�� Ż��");
      Jta_consulting = new JTextArea(1, 8);
      // JScrollPane consulting_text = new JScrollPane(Jta_consulting);
        
      ActionListener listener = new ActionListener() { //ȸ��Ż�� ��ư 
         
         @Override
         public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            System.out.println(tb_input);
            String temp = null;
            for(int i = 0; i < data.length;i++) {
              
               if(data[i][1] == tb_input) {
                  for(int j =0; j <4;j++) {
                  data[i][j] = null; 
                  
                  }
                  System.out.println(elements.get(i)[0].toString());
                  elements.remove(i);
                  
               }
               
               
            }
            for(int i =0; i<data.length;i++) {
                for(int j = 0; j<data[i].length;j++) {
                   if(data[i][j]==null) {
                      if(i==data.length-1) {
                         break;
                      }
                      temp =  data[i][j];
                      data[i][j] = data[i+1][j];
                      data[i+1][j] = temp;
                   }
                }
            }
            
            Grade_tb.repaint();
            
            
            
            try {
               BufferedWriter bf = new BufferedWriter(new FileWriter("Student.csv"));
               for(int i = 0; i < elements.size();i++) {
                  bf.write(elements.get(i)[0]+"\n");
               }
               bf.close();
               
            }
            catch(IOException ex) {
               ex.printStackTrace();
            }
            
         }
      };
      Btn_consulting.addActionListener(listener);
      
      gradePanel.add(lbl1);
      gradePanel2.add(sp);

      consultPanel2.add(Jta_consulting);
      consultPanel2.add(Btn_consulting);

      add(gradePanel);
      add(scroll);
      add(gradePanel3);
      add(consultPanel);
      add(consultPanel2);
      setSize(600, 600); // ȭ�� ũ��
      setVisible(true);
   }
   

   private class MyMouseListener extends MouseAdapter {
      public void mouseClicked(MouseEvent e) { // ���콺Ŭ���̺�Ʈ�߻���
         if (e.getButton() == 1) { // ��Ŭ����
            int row = Grade_tb.getSelectedRow(); // ���õǾ��� row���ϱ�
            if(Jta_consulting != null) {
               Jta_consulting.setText(null);
            }
            
            
            if (row != -1) { // ���� ���õǾ��� �����ΰ��
               tb_input = (String) Grade_tb.getValueAt(row, 1);
               Jta_consulting.append(tb_input);
            }
         }

         
      }
   }
}