package login;

import java.awt.Font;

import java.awt.Image;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import manager.Manager;
import professor.Professor;
import student.Student;
import info.Account;
public class Login extends JFrame{
	Image img = null;
	BufferedReader br;
	
	String id;
    String pwd;

   private Font f1;
   
   //�л� ȸ�� ������
   ArrayList<String[]> privacy_array; 
   // ȸ�� ���� �ӽ� ����
   String tmpInfo[];
   public Login()
   {
	   privacy_array = new ArrayList<>();
	 //csv file containing data
       String strFile = "Student.csv";

       //create BufferedReader to read csv file
	try {
		br = new BufferedReader( new FileReader(strFile));
		String strLine = "";
        StringTokenizer st = null;
        int tokenNumber;
        int ID_TOKEN_NUM=2, PWD_TOKEN_NUM=3;
        
        while( (strLine = br.readLine()) != null)
        {
        	


           //break comma separated line using ","
           st = new StringTokenizer(strLine, ",");

           //�� ��ū(�Ӽ�)�� �������� �κ�
           
           tmpInfo = new String[8];
           tokenNumber = 0;
           while(st.hasMoreTokens())
           {
        	   tmpInfo[tokenNumber] = st.nextToken();
	           tokenNumber++;
           }
           
           privacy_array.add(tmpInfo);
           
	    }
        br.close();
	} catch (FileNotFoundException e1) {
		// ���� �� ã������ ���� ����ó��
		e1.printStackTrace();
	}catch (IOException e1) {
		// ���� �о�ö��� ���� ����ó��
		e1.printStackTrace();
	}
	
	
       

      f1 = new Font("�ü�", Font.BOLD, 15); //Font settings

      
      JPanel p = new JPanel(); //Create panel
      p.setLayout(null);
      JLabel label = new JLabel(new ImageIcon("moble.png"));
      add(label);
      Label t1= new Label("�ʱⰪ");
      add(t1);
      t1.setFont(f1);
      Label t2= new Label("ID :�й�");
      add(t2);
      t2.setFont(f1);
      Label t3= new Label("Password : �ֹι�ȣ ���ڸ�");
      add(t3);
      t3.setFont(f1);

      Label b1= new Label("ID:");
      add(b1);
      Label b2= new Label("Password:");
      add(b2);
      TextField b3 = new TextField();   
      add(b3);
      TextField b4 = new TextField();
      add(b4);
      b4.setEchoChar('*');//Password *
      JButton b5 = new JButton("�α���");
      add(b5);
      JButton b6 = new JButton("ȸ������");
      add(b6);
      JButton b7 = new JButton("��й�ȣ ã��");
      add(b7);
      //Layout settings
      label.setBounds(0, 5, 450, 250);
      t1.setBounds(450, 70, 70, 40);
      t2.setBounds(450,120, 280, 40);
      t3.setBounds(450, 150,280, 40);
      b1.setBounds(40, 265, 40, 40);
      b2.setBounds(40, 305, 60, 40);
      b3.setBounds(150, 265, 200, 30);
      b4.setBounds(150, 305, 200, 30);
      b5.setBounds(380, 265, 90, 30);
      b6.setBounds(380, 305, 90, 30);
      b7.setBounds(480,265,150,70);
      add(p);
      setSize(700, 400);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("Login ");
      setVisible(true);
      
      //�α��� ��ư
      b5.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
        	  //�α��� �˻��
        	  //���� �Է��� ID
        	  boolean idCheck=false;
        	  boolean pwdCheck=false;
        	  String scanId = b3.getText().toString();
        	  
	    	  for(int c=0; c<privacy_array.size(); c++) {
	    	 	   String tt[] = privacy_array.get(c);
    			   //���̵� �������
		 		   if(tt[0].equals(scanId)){
		 			  idCheck=true;
		 			   //��й�ȣ�� ���� ���
		 			   if(tt[2].equals(b4.getText().toString())){
		 				  pwdCheck=true;
		 				  
		 				  //���� ��������
		 				 Account myInfo = Account.getInstance();
	 					 myInfo.setId(tt[0]);
	 					 myInfo.setName(tt[1]);
	 					 myInfo.setPwd(tt[2]);
	 					 myInfo.setMajor(tt[3]);
	 					 myInfo.setSecuNum(tt[4]);
	 					 myInfo.setMail(tt[5]);
	 					 myInfo.setAddress(tt[6]);
	 					 myInfo.setAddress(tt[7]);
		 				  
		 				  
		 				  //�����α��� ����
		 				  if(scanId.charAt(0)=='p') {
		 					  new Professor();
		 				  //�����α��� ����
		 				  }else if(scanId.charAt(0)=='m'){
			 	        	 new Manager();
			 	          //�л��α��� ����
		 				  }else{
		 					  
		 					 
		 					 
			 	        	 new Student();
		 				  }
		 				 dispose();
		 				  
		 			   }else { // ��й�ȣ�� Ʋ������ 
		 				  
		 			   }
		 		   }else { // ���̵� Ʋ������
		 			  
		 		   }
	    	  }
	    	  if(!idCheck) {
	    		  JOptionPane.showMessageDialog(null, "���� ���� �ʴ� ���̵��Դϴ�.");
	    	  }
	    	  else if(!pwdCheck) {
	    		  JOptionPane.showMessageDialog(null, "��й�ȣ�� Ʋ�Ƚ��ϴ�.");
	    	  }
          }
       });
      
      b6.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {// Go to the Sign up page
            new SignUp();
         }
      });
      
      b7.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {// Go to the Sign up page
             ForgetPassword page= new ForgetPassword(privacy_array);
          }
      });
      

   }
	   
}



