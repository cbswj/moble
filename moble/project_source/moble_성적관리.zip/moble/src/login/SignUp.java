package login;

import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

class SignUp extends JFrame {

	   private static final long serialVersionUID = 1L;


	   //Sign up Screen
	   public SignUp(){
	           JPanel p = new JPanel();
	           Label l1= new Label("�̸�*");   
	           Label l2 = new Label("�й�*");
	           Label l3= new Label("�н�����*");
	           Label l3_1 = new Label("8���̻�  / ������, Ư������ ����");
	           Label l4 = new Label("�а�*");
	           Label l5 = new Label("�ֹι�ȣ ");
	           Label l5_1 = new Label("  �� �����ϰ� �Է�");
	           Label l6 = new Label("E-mail*");
	           Label l7 = new Label("�ּ�");
	           Label l8 = new Label("�ڵ��� ��ȣ");
	           add(l1); add(l2); add(l3); add(l3_1); add(l4); add(l5); add(l5_1); add(l6); add(l7); add(l8);
	           
	           TextField t1 = new TextField();
	           TextField t2 = new TextField();
	           TextField t3 = new TextField();
	           TextField t4 = new TextField();
	           TextField t5 = new TextField();
	           TextField t6 = new TextField();
	           TextField t7 = new TextField();
	           TextField t8 = new TextField();
	           
	           add(t1); add(t2); add(t3); add(t4); add(t5); add(t6); add(t7); add(t8);
	           t3.setEchoChar('*'); //Password *
	           JButton j1 = new JButton("����");
	           JButton j2 = new JButton("���");
	           add(j1); add(j2);
	           //Layout settings
	           l1.setBounds(20, 50, 40, 40);
	           l2.setBounds(20, 90, 40, 40);
	           l3.setBounds(20,130,60,40);
	           l3_1.setBounds(300,128,200,40);
	           l4.setBounds(20, 172, 40, 40);
	           l5.setBounds(20, 217, 60, 40);
	           l5_1.setBounds(400,215,100,40);
	           l6.setBounds(20, 262, 60, 40);
	           l7.setBounds(20, 307, 60, 40);
	           l8.setBounds(20, 352, 90, 40);
	           t1.setBounds(120, 50, 200, 30);
	           t2.setBounds(120, 90, 200, 30);
	           t3.setBounds(120, 130, 200, 30);
	           t4.setBounds(120, 175, 280, 30);
	           t5.setBounds(120, 220, 280, 30);
	           t6.setBounds(120, 265, 280, 30);
	           t7.setBounds(120,310, 280, 30);
	           t8.setBounds(120,355, 280, 30);
	           j1.setBounds(125, 410, 80, 30);
	           j2.setBounds(240, 410, 80, 30); 
	           add(p);
	           setSize(600,500);
	           setTitle("Sign up");
	          
	           setVisible(true);
	           
	           j1.addActionListener(new ActionListener() {
	        
	               
	        	public void actionPerformed(ActionEvent T) {//Student data save
	        	//Exception Handling
	        	try{
	        		String text_Name = t1.getText().toString();
	        		String text_Snumber = t2.getText().toString();
	        		String text_Password = t3.getText().toString();
	        		String text_Department = t4.getText().toString();
	        		String text_Email = t6.getText().toString();
	        		//Ư������,����,���� ���� 8~20�ڸ�,��ҹ��� ����
	                String PwPattern1 =  "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[!@#$%^&*?,./\\\\<>|_-[+]=\\`~\\(\\)\\[\\]\\{\\}])[A-Za-z[0-9]!@#$%^&*?,./\\\\<>|_-[+]=\\`~\\(\\)\\[\\]\\{\\}]{8,20}$";
	                //��ĭ ����
	                String PwPattern2 = "";

	                Boolean t_1 = Pattern.matches(PwPattern2 ,text_Name);
	                Boolean t_2 = Pattern.matches(PwPattern1,text_Password); //text ���ڿ��� ���ϰ� ��ġ�ϸ� true ��ȯ
	                Boolean t_3 = Pattern.matches(PwPattern2, text_Department);
	                Boolean t_4 = Pattern.matches(PwPattern2,text_Email);
	            if(t_1==true)
	            {	JOptionPane.showMessageDialog(null, "�̸��� �Էµ��� �ʾҽ��ϴ�.");}
	            else if(text_Snumber.length()<7)
	            { JOptionPane.showMessageDialog(null, "�й��� �ùٸ��� �ʽ��ϴ�.");}
	            else if(t_3==true)
	            { JOptionPane.showMessageDialog(null, "�а��� �Էµ��� �ʾҽ��ϴ�.");}
	            else if(t_4 == true)
	            { JOptionPane.showMessageDialog(null, "�̸����� �Էµ��� �ʾҽ��ϴ�.");}
	            else if(t_2==true)
	        	{
	            	BufferedWriter save_csv = new BufferedWriter(new FileWriter("Student.csv",true));
		            BufferedWriter savegrade_csv = new BufferedWriter(new FileWriter("Grade.csv",true));//############�߰��Ⱥκ�
		            save_csv.write(t1.getText()+",");
		            save_csv.write(t2.getText()+",");
		            savegrade_csv.write(t1.getText()+","); //############�߰��Ⱥκ�
		            savegrade_csv.write(t2.getText()+",");//############�߰��Ⱥκ�
		            savegrade_csv.write("0"+","+"0"+","+"0"+"\n");//############�߰��Ⱥκ�
		            save_csv.write(t3.getText()+",");
		            save_csv.write(t4.getText()+",");
		            save_csv.write(t5.getText()+",");
		            save_csv.write(t6.getText()+",");
		            save_csv.write(t7.getText()+",");
		            save_csv.write(t8.getText()+"\n");
		            save_csv.close();
		            savegrade_csv.close(); ;//############�߰��Ⱥκ�
		            JOptionPane.showMessageDialog(null, "ȸ������ ����");
		            dispose();
	        	}
	        	else {
	        		JOptionPane.showMessageDialog(null, "��й�ȣ�� �ùٸ��� �ʽ��ϴ�.");
	        	}
	         }catch (Exception ex){ 
	            JOptionPane.showMessageDialog(null, "ȸ������ ����");
	         }
	      }
	   });
	           
	       
	       j2.addActionListener(new ActionListener() {

	      @Override
	      public void actionPerformed(ActionEvent e) {
	         dispose();      //dispose
	      }
	          
	       }
	     );
	}
}