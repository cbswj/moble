package login;

import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import info.Account;
import manager.Manager;
import professor.Professor;
import student.Student;

public class ForgetPassword extends JFrame{
	ArrayList<String[]> privacy_array;
	TextField t1, t2;
	public ForgetPassword(ArrayList<String[]> array)
	{
		privacy_array = array;
		 JPanel p = new JPanel();
         Label l1= new Label("�й� �Է� : ");   
         Label l2 = new Label("E-mail �Է� : ");
         add(l1); add(l2);
         
         JButton j1 = new JButton("ã��");
         JButton j2 = new JButton("���");
         add(j1); add(j2);
         
         t1 = new TextField();
         t2 = new TextField();
         add(t1); add(t2);
         
         l1.setBounds(20, 50, 80, 70);
         l2.setBounds(20, 95, 80, 70);
         
         t1.setBounds(110,70, 200, 30);
         t2.setBounds(110, 115, 200, 30);
         
         j1.setBounds(125, 310, 80, 30);
         j2.setBounds(240, 310, 80, 30);
         add(p);
         
         setSize(500,400);
         setTitle("Forget Password");
         
         setVisible(true);
         
         //��й�ȣ ����
         j1.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent T) {
            	  
            	 JOptionPane.showMessageDialog(null, checkInfo());
            	 
             }
          });
         
         
         j2.addActionListener(new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent e) {
           dispose();      
        }
            
         }
       );
	}
	
	public String checkInfo() {
		String id = t1.getText().toString();
		String email = t2.getText().toString();
		
		if(id.equals("")) {
			return "���̵� �Է����ּ���.";
		}
		
		if(email.equals("")) {
			return "�̸����� �Է����ּ���";
		}
		
		
		for(int c=0; c<privacy_array.size(); c++) {
   	 	   String tt[] = privacy_array.get(c);
   	 	  
   	 	   
			   //���̵� �������
		   if(id.equals(tt[0])) {
			   //�̸��ϱ��� �´°��
			   if(email.equals(tt[5])) {
				   return "ȸ������ ��й�ȣ�� " +'\''+tt[2]+'\''+" �Դϴ�.";
			   }
		   }
	    	 	   
		}
		return "��ϵ� ������ �����ϴ�.";
	}
}

