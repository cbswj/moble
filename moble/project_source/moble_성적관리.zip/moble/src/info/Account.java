package info;

public class Account {
	
	private String id; // ���̵� (�й�)
	private String pwd;  // ��й�ȣ
	private String name; //�̸�
	private String major; //����
	private String secuNum;
	private String email;
	private String address;
	private String phone;
	private String c;     //c���
	private String python;  //���̽�
	private String java;   //�ڹ�
	
	private String data[];
	
	private static Account myInfo;
	
	
	public static Account getInstance() {
		if(myInfo==null) {
			myInfo = new Account();
		}
		return myInfo;
	}
	
	public String[] getAccount() {
		// TODO Auto-generated method stub
		String[] account= {getId(), getName(), getC(), getPython(), getJava()};
		return account;
	}
	
	
	private Account(){
		
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getMail() {
		return email;
	}
	
	public void setMail(String email) {
		this.email = email;
	}
	
	public String getSecuNum() {
		return secuNum;
	}
	
	public void setSecuNum(String secuNum) {
		this.secuNum = secuNum;
	}
	
	public String getMajor() {
		return major;
	}
	
	public void setMajor(String major) {
		this.major = major;
	}
	
	public String getPwd(){
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public void setSubject(String c, String python, String java) {
		this.c =c;
		this.python = python;
		this.java = java;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public String getC() {
		return c;
	}
	
	public String getPython() {
		return python;
	}
	
	public String getJava() {
		return java;
	}
	
	public void setC(String c) {
		this.c = c;
	}
	
	public void setPython(String python) {
		this.python = python;
	}
	
	public void setJava(String java) {
		this.java = java;
	}
}
