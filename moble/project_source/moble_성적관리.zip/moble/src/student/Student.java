package student;

import java.awt.Choice;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.StringTokenizer;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

import info.Account;

public class Student extends JFrame {
   Choice Professor;
   JButton Btn_gradecheck;
   JButton Btn_consulting;
   JTextArea Jta_consulting;
   JPanel gradePanel,gradePanel2,gradePanel3,scholarship,scholarship2,nullpanel,nullpanel2,nullpanel3,nullpanel4,consultPanel,consultPanel2;
   JLabel lbl1,lbl2,lbl3;
   JTable Grade_tb;
   JList scholarship_lst;
   
   ArrayList<String[]> scholarList;
   DefaultListModel<String> m;
   
   //�� �̸�
   String subject[] = {"�й�","�̸�","C���","Python","Java"};
   //���� ���� ����
   String data[][] = new String[1][];
   

   Account myInfo;
   

   public Student(){
	   
      super("�л�");
      myInfo = Account.getInstance();
      
      openScholar(); // ���б� csv ����
      openGrade(); // ���� ����
      
      
      setLayout(new FlowLayout());
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      EtchedBorder eborder =  new EtchedBorder();
      
      lbl1 = new JLabel("���� Ȯ��");
      
      add(lbl1);
      
      
      //�������� �ҷ�����
      openGrade();
      
      //���̺��� ���� ���� ���� ����
      data[0] = new String[] {myInfo.getId(), myInfo.getName(), myInfo.getC(), myInfo.getPython(), myInfo.getJava()};
      
      
      Grade_tb = new JTable(data, subject);
      JScrollPane sp = new JScrollPane(Grade_tb);
      
      gradePanel = new JPanel();
      gradePanel2 = new JPanel();
      gradePanel3 = new JPanel();
      consultPanel = new JPanel();
      consultPanel2 = new JPanel();
      nullpanel = new JPanel();
      scholarship = new JPanel();
      scholarship2 = new JPanel();
      nullpanel2 = new JPanel();
      nullpanel3 = new JPanel();
      nullpanel4 = new JPanel();
      
      // Pane UI ũ�� ����
      gradePanel2.setPreferredSize(new Dimension(1000,44));
      gradePanel3.setPreferredSize(new Dimension(1000,44));
      nullpanel.setPreferredSize(new Dimension(1000,10));
      nullpanel2.setPreferredSize(new Dimension(1000,10));
      nullpanel3.setPreferredSize(new Dimension(1000,10));
      nullpanel4.setPreferredSize(new Dimension(1000,10));
      
      scholarship2.setPreferredSize(new Dimension(1000,100));
      Btn_gradecheck = new JButton("���� Ȯ��");
      lbl2 = new JLabel("��� ��û");
      Btn_consulting = new JButton("��� ��û");
      Jta_consulting = new JTextArea(3,20);
      JScrollPane consulting_text = new JScrollPane(Jta_consulting);
      
      Professor = new Choice();
      Professor.addItem("�赿��");
      Professor.addItem("������");
      Professor.addItem("������");
      
      lbl3 = new JLabel("���б� ����");
      m = new DefaultListModel<>();

      //���б� ����Ʈ �߰�
      writeScholar();
      
      scholarship_lst = new JList(m);
      //����Ʈ ũ�� ����
      scholarship_lst.setPreferredSize(new Dimension(650,100));
      
      //����Ʈ ��� ����
      scholarship_lst.setCellRenderer(new DefaultListCellRenderer() {
    	  public int getHorizontalAlignment() {
    		  return CENTER;
    	  }
      });
      
      //��� ��û ��ư
      Btn_consulting.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			//��� ��û�� �ൿ
			consulPost();
		}
	});
      
      gradePanel.add(lbl1);
      gradePanel2.add(sp);
      scholarship.add(lbl3);
      scholarship2.add(scholarship_lst);
      consultPanel.add(lbl2);
      consultPanel2.add(Professor);
      consultPanel2.add(consulting_text);
      consultPanel2.add(Btn_consulting);
      
      
      
      add(gradePanel);
      add(gradePanel2);
      add(gradePanel3);
      add(nullpanel);
      add(scholarship);
      add(nullpanel4);
      add(scholarship2);
      add(nullpanel2);
      add(consultPanel);
      add(nullpanel3);
      add(consultPanel2);
      setSize(600,600); //ȭ�� ũ��
      setVisible(true); 
   }
   
   //��� ��û ��ư Ŭ���� �ൿ
   public void consulPost() {
	   BufferedWriter save_csv;
		try {
			//���� ��¥ ��������
			Calendar calendar = Calendar.getInstance();
            java.util.Date date = calendar.getTime();
            
            //��¥ ���ڿ� ����
            String today = (new SimpleDateFormat("yyyy-MM-dd").format(date));
            
            //csv �����ϱ�
			save_csv = new BufferedWriter(new FileWriter("consulting.csv",true));
			save_csv.write(today+",");
		    save_csv.write(myInfo.getId()+",");
		    save_csv.write(myInfo.getName()+",");
		    save_csv.write(Professor.getItem(Professor.getSelectedIndex())+",");
		    save_csv.write(Jta_consulting.getText()+"\n");
		    save_csv.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
   }
   
   //�������� �ҷ�����
   public void openGrade() {
	   String tokenscList[] = new String[5]; //�ӽ�����
	   BufferedReader br;
	   String strFile = "Grade.csv";
	   
	   try {
		br = new BufferedReader( new FileReader(strFile));
		String strLine = "";
        StringTokenizer st = null;
        
        while( (strLine = br.readLine()) != null) {
        	
        	st = new StringTokenizer(strLine, ",");
        	
        	while(st.hasMoreTokens()) {
        		
    			String tokenId = st.nextToken();
    			tokenscList[0]= tokenId;
    			//�ڽ��� ���̵� ��
    			if(myInfo.getId().equals(tokenId)) {
    				for(int i=1; i<5; i++) {
    					tokenscList[i] = st.nextToken();
    				}
    				//�� ���� �����ͼ� ����
    				myInfo.setSubject(tokenscList[2], tokenscList[3], tokenscList[4]);
    				return;
    			}else {
    				break;
    			}
        	}
        }
        
      
		
	   } catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
   //���б� ����Ʈ �߰�
   public void writeScholar() {
	   //scholarList
	   //2���� �迭�̰�
	   // ���ٷ� ����
	   
	   //���б� ����Ʈ ����
	   String tmp;
	   
	   for(int i=0; i< scholarList.size(); i++) {
		   tmp="";
		   String t[]= scholarList.get(i);
		   for(int j=0; j<2; j++) {
			   tmp += t[j]+"  ";
			   if(j==1) {
				   if(t[1].equals("�������б�")) {
					   tmp += "1,000,000��";
				   }else if(t[1].equals("�ູ���б�")) {
					   tmp += "800,000��";
				   }else if(t[1].equals("�ٷ����б�")) {
					   tmp += "500,000��";
				   }
				   break;
			   }
		   }
		   m.addElement(tmp);
	   }
	   
   }
   
   
   //���б� ���� �ҷ�����
   public void openScholar() {
	   
	   scholarList = new ArrayList<>(); // ���б� ����Ʈ
	   BufferedReader br;
	   String strFile = "scholarship.csv";
	   
	   try {
		br = new BufferedReader( new FileReader(strFile));
		String strLine = "";
        StringTokenizer st = null;
        int lineNumber = 0, tokenNumber = 0;
        int ID_TOKEN_NUM=1;
        
        while( (strLine = br.readLine()) != null) {
        	
        	lineNumber++;
        	st = new StringTokenizer(strLine, ",");
        	
        	while(st.hasMoreTokens()) {
        		
        		
        		if(tokenNumber == ID_TOKEN_NUM) {
        			//������ ���̵�
        			String tokenId = st.nextToken();
        			
        			//�ڽ��� ���̵� ��
        			if(myInfo.getId().equals(tokenId)) {
        				String t1 = st.nextToken();
        				String t2 = st.nextToken();
        				scholarList.add(new String[] {t1,t2});
        			}
        			

        			ID_TOKEN_NUM += 4;
        			
        			//���̵� ��
        			//�ƴϸ� �Ȱ�������
        			//������ ���� ��������
        		}
        		tokenNumber++;
        		
    			//System.out.println(tokenNumber + " "+st.nextToken());
        		
        	}
        }
		
	   } catch (FileNotFoundException e) {
		   e.printStackTrace();
	   }catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
   

}
