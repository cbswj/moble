package professor;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

public class Pro_grade extends JFrame{
		
	   JButton Btn_consulting, Btn_consulting_1;
	   JTextArea Jta_consulting;
	
	   JPanel gradePanel,gradePanel2,gradePanel3,nullpanel,nullpanel2,nullpanel3,consultPanel,consultPanel2;
	   JLabel lbl1;
	   JTable Grade_tb;
	   BufferedReader br;
	   ArrayList<String[]> privacy_array = new ArrayList<>();
	   String id;
	   String pwd;
	   int tokenNumber = 0;
	   public Pro_grade(){
	      super("���� ����");
	      String strFile = "Grade.csv";
	      String[][] table = new String[1000][1000];
	       //create BufferedReader to read csv file      
		try {
			br = new BufferedReader( new FileReader(strFile));
			String strLine = "";
	        StringTokenizer st = null;
	        int lineNumber = 0;
	        int j = 0;
	        while( (strLine = br.readLine()) != null)
	        {
	        	
	           lineNumber++;
	           //break comma separated line using ","
	           st = new StringTokenizer(strLine, ",");
	           
	           //�� ��ū(�Ӽ�)�� �������� �κ�	           
	           while(st.hasMoreTokens())
	           {	           
		           for(j=0;j<=4;j++)
		           {           
		           table[tokenNumber][j] = st.nextToken();		           
		                     
		           }
		           tokenNumber++;
	           }
	        }
		} catch (FileNotFoundException e1) {
			// ���� �� ã������ ���� ����ó��
			e1.printStackTrace();
		}catch (IOException e1) {
			// ���� �о�ö��� ���� ����ó��
			e1.printStackTrace();
		}
		
		
		
		
	      setLayout(new FlowLayout());
	      EtchedBorder eborder =  new EtchedBorder();
	      
	      lbl1 = new JLabel("�л� ���� �Է�");
	      
	      add(lbl1);
	      
	      String subject[] = {"�й�","�̸�","C���","Python","Java"};
	      
	      String[][] data = new String[tokenNumber][1000];
	      for(int b = 0;b<tokenNumber;b++)
	      {
	    	
	    	  for(int a = 0;a<=4;a++)
	    	  	{
	    		  	data[b][a] = table[b][a];
	    	  	}

	      }
	      
	      Grade_tb = new JTable(data, subject);
	      JScrollPane sp = new JScrollPane(Grade_tb);
	      gradePanel = new JPanel();
	      gradePanel2 = new JPanel();
	      gradePanel3 = new JPanel();
	      consultPanel = new JPanel();
	      consultPanel2 = new JPanel();
	      nullpanel = new JPanel();
	      nullpanel2 = new JPanel();
	      nullpanel3 = new JPanel();
	      

	      
	      
	      gradePanel2.setPreferredSize(new Dimension(1000,300));//���̺� ũ������
	      nullpanel.setPreferredSize(new Dimension(1000,10));
	      nullpanel2.setPreferredSize(new Dimension(1000,10));
	      nullpanel3.setPreferredSize(new Dimension(1000,10));
	      Btn_consulting = new JButton("����"); //�����ư
	      Jta_consulting = new JTextArea(1,6);
	      
	      //�����ư ����
	      Btn_consulting.addActionListener(new ActionListener() {

		        @Override
		        public void actionPerformed(ActionEvent e) {
		        	try {
						BufferedWriter bfw = new BufferedWriter(new FileWriter("Grade.csv"));

					     for (int i = 0 ; i < Grade_tb.getRowCount(); i++)
					     {
					       
					       for(int j = 0 ; j < Grade_tb.getColumnCount();j++)
					       {
					         bfw.write((String)(Grade_tb.getValueAt(i,j)));
					         bfw.write(",");
					       }
					       bfw.newLine();
					     }
					     bfw.close();
											
						
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		        	
		        	JOptionPane.showMessageDialog(null, "���� �Ϸ�");
		        }
		            
		         }
		       );
	      	                 
	      gradePanel.add(lbl1);
	      gradePanel2.add(sp);
	     
	      consultPanel2.add(Btn_consulting);
    
	      
	      add(gradePanel);
	      add(gradePanel2);
	      add(gradePanel3);
	      add(nullpanel);
	   
	      add(nullpanel2);
	      add(consultPanel);
	      add(nullpanel3);
	      add(consultPanel2);
	      setSize(600,600); //ȭ�� ũ��
	      setVisible(true); 
	   }
	   

}
