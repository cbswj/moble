package professor;
import java.awt.Choice;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EtchedBorder;

import info.Account;

public class Pro_consulting extends JFrame{
   
   
   Choice  Professor;
  
   JButton Btn_consulting;
   JButton Btn_insert;
   JTextArea Jta_text; //��㳻��
   JPanel gradePanel,gradePanel2,gradePanel3,scholarship,scholarship2,nullpanel,nullpanel2,nullpanel3,consultPanel,consultPanel2;
   JLabel lbl1,lbl2,lbl3;
   JTable Grade_tb;
   JList scholarship_lst;
   String consult;
   String tb_input;
   int tokenNumber = 0;
   String input_arr[] = new String[100];
   
   Account myinfo;

   public Pro_consulting(){
      
      super("��� ����");
      BufferedReader br;
      String name=null;
      String id=null;
      String strFile = "consulting.csv";
      String arr[][]=new String[100][];
      
      ArrayList<String> privacy_array = new ArrayList<>();
      
      //���� �������� ��������
      myinfo = Account.getInstance();

      //create BufferedReader to read csv file
   try {
       br = new BufferedReader( new FileReader(strFile));
       String strLine = null;
       StringTokenizer st = null;
//     int NAME_TOKEN_NUM=1, ID_TOKEN_NUM=2;
       
       while( (strLine = br.readLine()) != null)
       {
          //break comma separated line using ","
    	   String consulList[]= strLine.split(",");
           
    	   if(myinfo.getName().equals(consulList[3])) {
    		   arr[tokenNumber]= consulList;
    		   tokenNumber++;
    	   }
           
       }
   } catch (FileNotFoundException e1) {
      // ���� �� ã������ ���� ����ó��
      e1.printStackTrace();
   } catch (IOException e1) {
      // ���� �о�ö��� ���� ����ó��
      e1.printStackTrace();
   }
   
      setLayout(new FlowLayout());
      EtchedBorder eborder =  new EtchedBorder();
      
      lbl1 = new JLabel("��� ��û ���");
      lbl1.setPreferredSize(new Dimension(100,15));
      
      
      
      String subject[] = {"��¥","�й�","�л��̸�","��米��","��㳻��"};
      String[][] data = new String[tokenNumber][1000] ;
      for(int i=0; i<tokenNumber;i++)
      {
    	  
         for(int j=0; j<5; j++)
         {
            data[i][j]=arr[i][j];
            
            input_arr[i] = data[i][4];
            if(j ==4) {
               data[i][j] = "...";
            }
         }
      }
      
      Grade_tb = new JTable(data, subject);
      JScrollPane sp = new JScrollPane(Grade_tb);
      Grade_tb.addMouseListener(new MyMouseListener2());
      
      gradePanel = new JPanel();
      gradePanel2 = new JPanel();
      consultPanel = new JPanel();
      consultPanel2 = new JPanel();
      scholarship = new JPanel();
      scholarship2 = new JPanel();

      Jta_text = new JTextArea(50,50); 

      gradePanel2.setPreferredSize(new Dimension(1000,400));//(1000,66) 66�κ��� �����ε� �����ؾ���

      
      Btn_consulting = new JButton("����");

      Btn_consulting.addActionListener(new ActionListener() {

           @Override
           public void actionPerformed(ActionEvent e) {
              JButton btn = (JButton) e.getSource();
            if(btn.getText().equals("����"))
               btn.setText("�Ϸ�");
            else 
               btn.setText("����");
         
              
              try {
               BufferedWriter bfw = new BufferedWriter(new FileWriter("Grade.csv"));
               
                 for (int i = 0 ; i < Grade_tb.getRowCount() ; i++)
                 {
                   
                   for(int j = 0 ; j < Grade_tb.getColumnCount();j++)
                   {
                     bfw.write((String)(Grade_tb.getValueAt(i,j)));
                     bfw.write(",");
                   }
                   bfw.newLine();
                 }
                 bfw.close();

            } catch (IOException e1) {
               // TODO Auto-generated catch block
               e1.printStackTrace();
            }
           }
               
            }
          );

      
      JScrollPane consulting_text = new JScrollPane(Jta_text);

      DefaultListModel<String> m = new DefaultListModel<>();
      
      gradePanel.add(lbl1);
      gradePanel2.add(sp);
         
      add(gradePanel);
      add(gradePanel2);
      add(scholarship);
      add(consultPanel);
      add(Jta_text);
      setSize(800,800); //ȭ�� ũ��
      setVisible(true); 
      Btn_consulting.setBounds(800, 500, 10, 30);
   }
 
   private class MyMouseListener2 extends MouseAdapter {
         public void mouseClicked(MouseEvent e) { // ���콺Ŭ���̺�Ʈ�߻���
            System.out.println(Grade_tb.getSelectedRow());
           System.out.println(Grade_tb.getValueAt(2, 2));
            if (e.getButton() == 1) { // ��Ŭ����
               int row = Grade_tb.getSelectedRow(); // ���õǾ��� row���ϱ�
               if(Jta_text != null) {
                  Jta_text.setText(null);
               }
               
               if (row != -1) { // ���� ���õǾ��� �����ΰ��
                  tb_input = (String) input_arr[Grade_tb.getSelectedRow()];
                  Jta_text.append(tb_input);
               }
            }

         }
      }
 
}