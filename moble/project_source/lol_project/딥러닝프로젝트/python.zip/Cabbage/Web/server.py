# -*- coding: utf-8 -*-
from flask import Flask, render_template, request

import datetime
import tensorflow as tf
import numpy as np

app = Flask(__name__)

X = tf.placeholder(tf.float32, shape=[None,4]) #4개의 변인이 담길수 있게
Y = tf.placeholder(tf.float32, shape=[None,1]) 
W = tf.Variable(tf.random_normal([4,1]), name="weight") #가중치
b = tf.Variable(tf.random_normal([1]), name="bias") #bias 값

hypothesis = tf.matmul(X,W) +b 

#저장된것을 가져오기 위한 객체 초기화
saver = tf.train.Saver()
model= tf.global_variables_initializer()

sess = tf.Session()
sess.run(model)

save_path="./model/saved.cpkt"
saver.restore(sess,save_path) #해당 세션에 저장된 학습 모델을 불러올수 있도록 함

@app.route("/", methods=['GET', 'POST'])
def index():
	if request.method == 'GET': #일반적인 형태로 웹사이트 접속 시 그냥 웹사이트를 보여줌
		return render_template('index.html')
	if request.method == 'POST' : # 사용자가 배추가격을 예상하기 위해서 4가지 데이터를 전송한 경우
		avg_temp = float(request.form['avg_temp'])
		min_temp = float(request.form['min_temp']) #4가지 데이터를 입력 받아서
		max_temp = float(request.form['max_temp'])
		rain_fall = float(request.form['rain_fall'])
		
	price=0
	
	#기존에 학습된 데이터가 2차원 배열이기 때문에 맞추어 줘야 한다.
	data = ((avg_temp, min_temp, max_temp, rain_fall),)
    #사용자가 입력한 데이터를 토대로 행렬로 초기화를 해주고
	arr = np.array(data, dtype=np.float32)
	x_data = arr[0:4]
    #입력한 데이터를 X에 담아서 모델을 돌려보았다
	dict = sess.run(hypothesis, feed_dict={X: x_data})
    #데이터를 하나만 넣었기 때문에 출력은 하나만 하면 된다.
	price= dict[0]
	return render_template('index.html',price=price)
	
	
	
if __name__ == '__main__':
	app.run(debug=True)

