
# coding: utf-8

# In[1]:


import pymssql # mssql 연동
import pandas as pd #데이터프레임


# In[29]:


class COVID_DB:
    conn = None
    cursor = None
    df = pd.DataFrame(columns=['제품명','필터등급','제조원','크기','가격','수량'])
    col=['제품명','필터등급','제조원','크기','가격','수량']
    
    #클래스 만들면 DB에 있는걸 모두 끌어와서 데이터프레임에 넣어준다.
    def __init__(self):
        List=[]
        self.conn = pymssql.connect(server="192.168.159.130", user="sa", password="sql1234.",database="covid_19")
        self.cursor = self.conn.cursor()
        self.cursor.execute("select * from stock order by quantity desc")
        row = self.cursor.fetchone()
        while row:
            List.append([row[0],row[1],row[2],row[3],row[4],row[5]])
            row = self.cursor.fetchone()
        self.conn.close()
        row=0
        for L in List:
            row +=1
            for i in range(0,6):
                self.df.loc[row,self.col[i]]=L[i]
                
    def select_db(self, name):
        List=[]
        df = pd.DataFrame(columns=['제품명','필터등급','제조원','크기','가격','수량'])
        
        self.conn = pymssql.connect(server="192.168.159.130", user="sa", password="sql1234.",database="covid_19")
        self.cursor = self.conn.cursor()
        sql = "SELECT * FROM stock WHERE pd_name like '%{0}%' ORDER BY quantity desc".format(name)
        self.cursor.execute(sql)
        row = self.cursor.fetchone()
        while row:
            List.append([row[0],row[1],row[2],row[3],row[4],row[5]])
            row = self.cursor.fetchone()
        self.conn.close()
        row=0
        for L in List:
            row +=1
            for i in range(0,6):
                df.loc[row,self.col[i]]=L[i]
        print(df)
    
    def insert_db(self, name, grade, manufac, size, price, quan):
        self.conn = pymssql.connect(server="192.168.159.130", user="sa", password="sql1234.",database="covid_19")
        self.cursor = self.conn.cursor()
        sql = "INSERT INTO stock VALUES (%s, %s, %s, %s, %d, %d)"
        self.cursor.execute(sql, (name,grade, manufac, size, price, quan))
        self.conn.commit()
        self.conn.close()
    
    def apply_db(self, name, quan):
        self.conn = pymssql.connect(server="192.168.159.130", user="sa", password="sql1234.",database="covid_19")
        self.cursor = self.conn.cursor()
        sql = "UPDATE stock set quantity += %d where pd_name = %s"
        self.cursor.execute(sql,(quan,name))
        self.conn.commit()
        self.conn.close()
        
    def subtract_db(self, name, quan):
        self.conn = pymssql.connect(server="192.168.159.130", user="sa", password="sql1234.",database="covid_19")
        self.cursor = self.conn.cursor()
        sql = "UPDATE stock set quantity -= %d where pd_name = %s"
        self.cursor.execute(sql,(quan,name))
        self.conn.commit()
        self.conn.close()
        
    
    
        
        

        
        

