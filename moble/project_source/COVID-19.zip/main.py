
# coding: utf-8

# In[1]:


import database as db # 데이터베이스 클래스 가져오기
import datetime # 엑셀 이름을 날짜로 하기 위해


# In[3]:


mask_db = db.COVID_DB()
while(True):
    print("\n안녕하세요 마스크 재고관리시스템입니다.")
    condition = int(input("(1) 재고 보기 /(2) 재고 관리 /(3) 종료"))
    
    if condition == 1:
        while(True):
            print("\n재고 현황입니다.")
            view_condition = int(input("(1) 전체 재고 보기 /(2) 검색 /(3) 액셀 변환 (4) 종료"))
            if view_condition == 1:
                print("전체 재고")
                print(mask_db.__init__())
                print(mask_db.df)  #현재 마스크를 재고 수량의 내림차순으로 보여줍니다.
            elif view_condition == 2:
                print("검색 기능")
                name = input("제품명 : ")
                mask_db.select_db(name)  #입력한 내용이 포함되어 있는 마스크 들을 검색 (LIKE 문 사용)
            elif view_condition == 3:
                print("액셀 변환")
                now = datetime.datetime.now()
                time = now.strftime('%y-%m-%d')
                mask_db.df.to_csv(time+'.csv',encoding='utf-8') # 현재시간을 파일명으로 가진 액셀 생성
                print("%s 액셀 생성 완료" %time)
            elif view_condition == 4:
                print("재고 현황을 종료합니다.")
                break
            else:
                print("잘못 입력하셨습니다.")
    elif condition ==2:
        while(True):
            print("\n재고 관리 모드 입니다.")
            mg_condition = int(input("(1) 신규 재고 반입 /(2) 기존 재고 반입/반출 /(3) 종료"))
            if mg_condition == 1:
                new_input_list=[]
                print("넣으실 재고를 입력해주세요")
                new_input_list.append(input("제품명 : "))
                new_input_list.append(input("필터등급 : "))
                new_input_list.append(input("제조회사 : "))
                new_input_list.append(input("크기 : (소형/중형/대형)"))
                new_input_list.append(int(input("가격 : ")))
                new_input_list.append(int(input("수량 : ")))
                mask_db.insert_db(new_input_list[0], new_input_list[1], new_input_list[2], new_input_list[3], new_input_list[4], new_input_list[5])
                print("%s 재고를 %d개 넣었습니다." %(new_input_list[0],new_input_list[5]))
            elif mg_condition ==2:
                input_condition = None
                input_st = ["반입","반출"] 
                input_list=[]
                input_condition = int(input("(1) 재고 반입 /(2) 재고 반출"))
                print("%s할 재고와 수량을 입력해주세요" %input_st[input_condition-1])
                input_list.append(input("제품명 : "))
                input_list.append(int(input("수량 : ")))
                if input_condition==1 :
                    mask_db.apply_db(input_list[0], input_list[1])
                elif input_condition==2:
                     mask_db.subtract_db(input_list[0], input_list[1])
                print("%s 재고 %d개 %s 완료." %(input_list[0], input_list[1], input_st[input_condition-1]))
                                      
            elif mg_condition ==3:
                print("재고 관리 모드를 종료합니다.")
                break
            else:
                print("잘못 입력하셨습니다.")
    elif condition ==3:
        print("\n재고 관리 시스템을 종료합니다.")
        break
    else:
        print("잘못 입력하셨습니다.")
            
            

