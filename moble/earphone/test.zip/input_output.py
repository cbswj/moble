from server import manufacturing
class input(manufacturing):
     print(manufacturing.output(["7061-6-0-0.wav"]))