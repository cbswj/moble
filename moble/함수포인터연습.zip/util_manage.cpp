#include<iostream>
#include "util_manage.h"

using namespace std; 

void func_menu_1() {
	cout << "111" << endl;
}
void func_menu_2() {
	cout << "222" << endl;

}
void func_menu_3() {
	cout << "333" << endl;

}
void func_menu_4() {
	cout << "444" << endl;

}
void func_menu_5() {
	cout << "555" << endl;
}
void func_menu_6() {
	cout << "666" << endl;
}
void func_menu_7() {
	cout << "777" << endl;
}
void func_menu_8() {
	cout << "888" << endl;
}
void func_menu_9() {
	cout << "999" << endl;
}
void func_menu_10() {
	cout << "000" << endl;
}
