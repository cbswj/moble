#pragma once

void func_menu_1();
void func_menu_2();
void func_menu_3();
void func_menu_4();
void func_menu_5();
void func_menu_6();
void func_menu_7();
void func_menu_8();
void func_menu_9();
void func_menu_10();

